echo add 000 > /proc/modmultilist/default
echo create new > /proc/modmultilist/control 
echo add 11 > /proc/modmultilist/new
echo add 12 > /proc/modmultilist/new
echo create new2 > /proc/modmultilist/control 
echo create new3 > /proc/modmultilist/control 
echo add 21 > /proc/modmultilist/new2
echo add 22 > /proc/modmultilist/new2
echo add 23 > /proc/modmultilist/new2
echo add 0001 > /proc/modmultilist/default
echo add 31 > /proc/modmultilist/new3
echo delete new2 > /proc/modmultilist/control




