#include <linux/errno.h>
#include <sys/syscall.h>
#include <linux/unistd.h>
#include <stdio.h>
#define __NR_LEDCTL 316

long lin_ledctl(unsigned int leds){
   return (long) syscall(__NR_LEDCTL, leds);
}

unsigned int advance(unsigned int mask, int direction){
	unsigned int newmask;
	if(direction == 1){
	  if(mask == 0x1)	newmask = 0x4;
	  if(mask == 0x2)	newmask = 0x1;
	  if(mask == 0x4)	newmask = 0x2;
	}else if(direction == 2){
	  if(mask == 0x1)	newmask = 0x2;
	  if(mask == 0x2)	newmask = 0x4;
	  if(mask == 0x4)	newmask = 0x1;	  
	}else if(direction == 3){
	  if(mask == 0x7)	newmask = 0x0;
	  if(mask == 0x0)	newmask = 0x7;
	}
  return newmask;
}

unsigned int getInitialMask(int direction){
	unsigned int choice;

	if(direction == 1) choice = 0x4;
	else if(direction == 2) choice = 0x1;
	else if(direction == 3) choice = 0x7;

	return choice;
}

int checkRightArguments(int direction, int time, int jumps){
	int error = 0;
	if(direction < 1 || direction > 3){
		printf("Usage:\n");
		printf("       Direction: 1-Right 2-Left 3-Blink\n");
		error = -1;
	}else if(time < 1 || time > 3){
		printf("Usage:\n");
		printf("       Velocity: 1 to 3\n");
		error = -1;
	}else if(jumps < 3 || jumps > 18){
		printf("Usage:\n");
		printf("       Jumps: 3 to 18 \n");
		error = -1;
	}
	return error;
}

int main(int argc, char *argv[]){
   	int direction;
	int velocity, time;
	int jumps;
	int i, error;
	unsigned int choice = 0x0;
   if (argc != 4){
	printf("Usage: ./leds_user <Direction> <Time> <Jumps>\n");
	printf("       Direction: 1-Right 2-Left 3-Blink\n");
	printf("       Velocity: 1 to 3\n");
	printf("       Jumps: 3 to 18 \n");
	return -1;
  }else{ 
	/*ASIGNACION ARGUMENTOS*/
   	direction = atoi(argv[1]);
	velocity = atoi(argv[2]);
	jumps = atoi(argv[3]);
	time = 1500000/velocity;
	lin_ledctl(0x0);
	sleep(1);
	/*COMPROBACIONES ARGUMENTOS*/
	if(checkRightArguments(direction, velocity, jumps) == 0){
		choice = getInitialMask(direction);
		lin_ledctl(choice);
		usleep(time);
		for(i=0;i<jumps;i++){		  
		  	choice = advance(choice, direction);
			error = lin_ledctl(choice);
		  	usleep(time);
		}
		if(error != 0){
			perror("The following error occurred");
			return -1; //errno;
		}
		else return 0;
	}else{
		return -1;
	}
  }
}


