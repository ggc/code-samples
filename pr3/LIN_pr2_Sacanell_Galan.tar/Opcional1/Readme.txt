Funcionamiento de la parte opcional:

/****************************************/

	El programa admite tres parámetros.
		Direction :	Este parámetro decide que modo de uso va a emplear.
				  1- Las luces empiezan en NUM y van "saltando" hacia la derecha.
				  2- Las luces empiezan en SCROLL y van "saltando" hacia la izquierda.
				  3- Se encienden todas las luces y parpadean.
		Velocity:	Decide la velocidad de ejecución del programa.
		Jumps:		Determina la cantidad de saltos que van a realizar las luces, independientemente del modo.

/****************************************/
