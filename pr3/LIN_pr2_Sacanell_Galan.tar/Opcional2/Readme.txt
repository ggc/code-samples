
Arquitectura interna de linux y android
Practica opcional C: Simil onda vital chocando de Dragon Ball.

 Uso:
blink_user color1 color2
color1,color2: Red,Green,Blue,Yellow,Cyan,Pink

 En esta parte opcional la funcion realiza una animacion de dos barras 
enfrentadas y oscilantes. 
 
 Comenzando desde los extremos se colorean los leds de los colores elegidos 
gradualmente hasta el centro. Posteriormente y de forma aleatoria variara 
el centro manteniendo los leds que lo rodean mas brillantes. Cuando una barra 
coloree integramente el BlinkStick Strip finalizara.
