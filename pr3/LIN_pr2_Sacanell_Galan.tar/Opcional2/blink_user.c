#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define NOCOLOR 0x000000
#define TIME_SLEEPING 350000
#define FILEPATH "/dev/usb/blinkstick0" 


/*PROTOTIPOS*/
unsigned int getBaseColor(char *colorname);
unsigned int getShinyColor(char *colorname);
void initializeStick(int repetition);
int checkRightArguments(char *color);
void refreshFight();

unsigned int color1, color1b, color2, color2b;
FILE *  pFile;
int fight;

/*MAIN*/
int main(int argc, char *argv[]){
	int random;
	fight = 4;
	time_t t;
	int repetition;
	
	//Comprobamos numero de argumentos
	if (argc != 3){
		printf("Usage: ./ledctl_invoke <Color1> <Color2>\n");
		printf("       colors: red green blue\n");

		return -1;
	}else{
	  if((checkRightArguments(argv[1]) == 0) && (checkRightArguments(argv[2]) == 0)){
			//Asignamos los colores a utilizar
			color1 = getBaseColor(argv[1]);
			color1b = getShinyColor(argv[1]);
			color2 = getBaseColor(argv[2]);
			color2b = getShinyColor(argv[2]);
			//Inicializamos
			pFile = fopen(FILEPATH,"w");	

			if(pFile != NULL){
				for(repetition = 1; repetition <= 4; repetition++){
					initializeStick(repetition);
				}
				refreshFight();
				while((fight > 0) && (fight < 8)){
					//Conseguimos el numero random
					srand((unsigned) time(&t));
					random = rand() % 2;
					if(random == 0){	//Si random par avanza hacia lado derecho
						fight++;
					}
					if(random == 1){	//Si random par avanza hacia lado izquierdo
						fight--;
					}
					refreshFight();
				}
				fclose(pFile);
				return 0;
			}else{
	printf("Problem opening the file\n");
	return -1;
}
		}else{
			printf("Wrong arguments\n");

			return -1;
		}
	}	
}


/*IMPLEMENTACIONES*/
unsigned int getBaseColor(char *colorname){
	unsigned int color;

	if(strcmp(colorname, "red")==0) color=0x050000;
	else if(strcmp(colorname, "green")==0) color=0x000500;
	else if(strcmp(colorname, "blue")==0) color=0x000005;
	else if(strcmp(colorname, "yellow")==0) color=0x050500;
	else if(strcmp(colorname, "cyan")==0) color=0x000505;
	else if(strcmp(colorname, "pink")==0) color=0x020005;
	else	color = 0x000000;

	return color;
}

unsigned int getShinyColor(char *colorname){
	unsigned int color;

	if(strcmp(colorname, "red")==0) color=0x220000;
	else if(strcmp(colorname, "green")==0) color=0x002200;
	else if(strcmp(colorname, "blue")==0) color=0x000022;	
	else if(strcmp(colorname, "yellow")==0) color=0x222200;	
	else if(strcmp(colorname, "cyan")==0) color=0x002222;
	else if(strcmp(colorname, "pink")==0) color=0x110022;


	else	color = 0x000000;

	return color;
}

void initializeStick(int repetition){
	char *str=malloc(88*sizeof(char));
	char *strAux=malloc(88*sizeof(char));
	pFile = fopen(FILEPATH,"w");	
	
	int i;


	if(pFile != NULL){

		for(i=0;i<repetition;i++){
			sprintf(strAux,"%d:0x%x,",i ,color1);
			strcat(str, strAux);
		}
		for(i=8-repetition;i<=7;i++){
			sprintf(strAux,"%d:0x%x,",i ,color2);
			strcat(str, strAux);
		}

		fputs(str, pFile);
		usleep(TIME_SLEEPING);
	}
	free(str);
	free(strAux);
	fclose(pFile);
}


int checkRightArguments(char *color){
	int error = 0;

	if((strcmp(color, "red") != 0) && 
	   (strcmp(color, "green") != 0) && 
	   (strcmp(color, "blue") != 0) && 
	   (strcmp(color, "yellow") != 0) && 
	   (strcmp(color, "pink") != 0) && 
	   (strcmp(color, "cyan") != 0)){
		printf("Usage:\n");
		printf("       colors: red green blue cyan pink yellow\n");
		error = -1;
	}

	return error;
}

void refreshFight(){
	char *str=malloc(88*sizeof(char));
	char *strAux=malloc(88*sizeof(char));
	pFile = fopen(FILEPATH,"w");	

	int i=0;

	if(pFile != NULL){
		if(fight == 0){		//Para que brillen los dos de mas a la izquierda
			sprintf(strAux,"0:0x%x,1:0x%x,",color2b, color2b);
			strcat(str, strAux);
			for(i=fight+2;i<8;i++){
				sprintf(strAux,"%d:0x%x,",i ,color2);
				strcat(str, strAux);
			}
		}else if(fight == 8){	//Para que brillen los dos de mas a la derecha
			for(i=0;i<fight-2;i++){
				sprintf(strAux,"%d:0x%x,",i ,color1);
				strcat(str, strAux);
			}	
			sprintf(strAux,"6:0x%x,7:0x%x,",color1b, color1b);
			strcat(str, strAux);
		}else{		//Para todos los casos intermedios

			//Colorea el color base tipo 1
			for(i=0;i<fight-1;i++){
				sprintf(strAux,"%d:0x%x,",i ,color1);
				strcat(str, strAux);
			}	
			//Colorea el color shiny tipo 1
			sprintf(strAux,"%d:0x%x,",fight-1 ,color1b);
			strcat(str, strAux);
			//Colorea el color shiny tipo 2
			sprintf(strAux,"%d:0x%x,",fight ,color2b);
			strcat(str, strAux);
			//Colorea el color base tipo 1		
			for(i=fight+1;i<8;i++){
				sprintf(strAux,"%d:0x%x,",i ,color2);
				strcat(str, strAux);
			}
		}
		fputs(str, pFile);
		usleep(TIME_SLEEPING);
	}
	free(str);
	free(strAux);
	fclose(pFile);
}



