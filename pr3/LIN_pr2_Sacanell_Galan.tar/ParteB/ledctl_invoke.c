#include <linux/errno.h>
#include <sys/syscall.h>
#include <linux/unistd.h>
#include <stdio.h>
#define __NR_LEDCTL 316

long lin_ledctl(unsigned int leds){
   return (long) syscall(__NR_LEDCTL, leds);
}

int main(int argc, char *argv[]){
   int error;
   char *token = argv[1];
   unsigned int choice;

   if (argc < 2){
	printf("Usage: ./ledctl_invoke <ledmask>\n");
  }else{   
   if(sscanf(token,"0x%x",&choice)){
     error = lin_ledctl(choice);
   }
   if (error != 0)     perror ("The following error occurred");
}
     return error;
}


