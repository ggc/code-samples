#include <linux/syscalls.h>
#include <linux/kernel.h>
#include <asm-generic/errno.h>
#include <linux/init.h>
#include <linux/tty.h>      /* For fg_console */
#include <linux/kd.h>       /* For KDSETLED */
#include <linux/vt_kern.h>

#define BITSET(var, bitnum) ((var) |= (1 <<(bitnum)))
#define BITCLR(var, bitnum) ((var) &= ~(1 <<(bitnum)))
#define BITTST(var, bitnum) ((var) & (1 <<(bitnum)))


struct tty_driver* kbd_driver= NULL;

/* Get driver handler */
struct tty_driver* get_kbd_driver_handler(void){
   printk(KERN_INFO "modleds: loading\n");
   printk(KERN_INFO "modleds: fgconsole is %x\n", fg_console);
   return vc_cons[fg_console].d->port.tty->driver;
}

/* Set led state to that specified by mask */
static inline int set_leds(struct tty_driver* handler, unsigned int mask){
    return (handler->ops->ioctl) (vc_cons[fg_console].d->port.tty, KDSETLED,mask);
}

SYSCALL_DEFINE1(lin_ledctl, unsigned int, leds)
{
   unsigned int newmask = 0x0;

//Set the new mask that we are going to use
  if(BITTST(leds, 2) == 4)	BITSET(newmask,1);

  if(BITTST(leds, 1) == 2)	BITSET(newmask,2);

  if(BITTST(leds, 0) == 1)	BITSET(newmask,0);


   kbd_driver= get_kbd_driver_handler();
      
   set_leds(kbd_driver,newmask);
   
   return 0;
}
